import java.util.ArrayList;
import java.util.Random;

public class Farm {
    static final int DOG_NUM = 5;
    static final int SHEEP_NUM = 10;
    Object[][] farm;
    ArrayList<Dog> dogs;
    ArrayList<Sheep> sheep;
    Random random = new Random();

    Farm(int n, int m) {
        dogs = new ArrayList<Dog>();
        sheep = new ArrayList<Sheep>();
        if (n % 3 == 0 && m % 3 == 0) {
            farm = new Object[n + 2][m + 2];
            initializeFarm(n + 2, m + 2);

        } else {
            farm = new Object[14][14];
            initializeFarm(14, 14);
        }
    }

    private void initializeFarm(int n, int m) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (i == 0 || i == n - 1 || j == 0 || j == m - 1) {
                    farm[i][j] = new Wall();
                } else {
                    farm[i][j] = new Empty();
                }
            }
        }
        placeAnimals();
        placeGates();
    }

    private boolean isValidCell(int x, int y) {
        return x > 0 && x < farm.length - 1 && y > 0 && y < farm[0].length - 1;
    }

    private void placeGates() {
        int posTop = random.nextInt(farm[0].length - 2) + 1;
        int posBottom = random.nextInt(farm[0].length - 2) + 1;
        int posLeft = random.nextInt(farm.length - 2) + 1;
        int posRight = random.nextInt(farm.length - 2) + 1;

        farm[0][posTop] = new Gate();
        farm[farm.length - 1][posBottom] = new Gate();
        farm[posLeft][0] = new Gate();
        farm[posRight][farm[0].length - 1] = new Gate();
    }

    private void placeAnimals() {
        int sectorH = (farm.length - 2) / 3;
        int sectorW = (farm[0].length - 2) / 3;
        for (int i = 0; i < SHEEP_NUM; i++) {
            int x = random.nextInt(sectorH) + sectorH + 1;
            int y = random.nextInt(sectorW) + sectorW + 1;
            if (farm[x][y] instanceof Empty) {
                Sheep s = new Sheep(x, y);
                farm[x][y] = s;
                sheep.add(s);
            } else {
                i--;
            }
        }
        int sector = random.nextInt(8);
        for (int i = 0; i < DOG_NUM; i++) {
            int x, y;
            switch (sector) {
                case 0:
                    x = random.nextInt(sectorH) + 1;
                    y = random.nextInt(sectorW) + 1;
                    break;
                case 1:
                    x = random.nextInt(sectorH) + 1;
                    y = random.nextInt(sectorW) + sectorW + 1;
                    break;
                case 2:
                    x = random.nextInt(sectorH) + 1;
                    y = random.nextInt(sectorW) + 2 * sectorW + 1;
                    break;
                case 3:
                    x = random.nextInt(sectorH) + sectorH + 1;
                    y = random.nextInt(sectorW) + 1;
                    break;
                case 4:
                    x = random.nextInt(sectorH) + sectorH + 1;
                    y = random.nextInt(sectorW) + 2 * sectorW + 1;
                    break;
                case 5:
                    x = random.nextInt(sectorH) + 2 * sectorH + 1;
                    y = random.nextInt(sectorW) + 1;
                    break;
                case 6:
                    x = random.nextInt(sectorH) + 2 * sectorH + 1;
                    y = random.nextInt(sectorW) + sectorW + 1;
                    break;
                case 7:
                    x = random.nextInt(sectorH) + 2 * sectorH + 1;
                    y = random.nextInt(sectorW) + 2 * sectorW + 1;
                    break;
                default:
                    x = 1;
                    y = 1;
                    break;
            }
            if (farm[x][y] instanceof Empty) {
                Dog d = new Dog(x, y);
                farm[x][y] = d;
                dogs.add(d);
            } else {
                i--;
            }
        }
    }

    public void printFarm() {
        System.out.print("\033[H\033[2J");
        System.out.print("\u001B[0;0H");
        for (int i = 0; i < farm.length; i++) {
            for (int j = 0; j < farm[i].length; j++) {
                System.out.print(farm[i][j].toString() + " ");
            }
            System.out.println();
        }
    }

    class Sheep implements Runnable {
        private int x;
        private int y;

        Sheep(int x, int y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public void run() {
            try {
                while (true) {
                    Thread.sleep(200);
                    synchronized (farm) {
                        if (isDogNear()) {
                            moveFromDog();
                        } else {
                            sheepMove();
                        }
                    }
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        private void moveFromDog() {
            if (y - 1 > 0 && farm[x][y - 1] instanceof Empty) {
                farm[x][y - 1] = new Sheep(x, y - 1);
                farm[x][y] = new Empty();
            } else if (y + 1 < farm[0].length - 1 && farm[x][y + 1] instanceof Empty) {
                farm[x][y + 1] = new Sheep(x, y + 1);
                farm[x][y] = new Empty();
            } else if (x - 1 > 0 && farm[x - 1][y] instanceof Empty) {
                farm[x - 1][y] = new Sheep(x - 1, y);
                farm[x][y] = new Empty();
            } else if (x + 1 < farm.length - 1 && farm[x + 1][y] instanceof Empty) {
                farm[x + 1][y] = new Sheep(x + 1, y);
                farm[x][y] = new Empty();
            } else if (farm[x][y - 1] instanceof Gate || farm[x][y + 1] instanceof Gate
                    || farm[x - 1][y] instanceof Gate || farm[x + 1][y] instanceof Gate) {
                farm[x][y] = new Empty();
                printFarm();
                System.out.println("Sheep escaped!");
                System.out.println("Coordinates of the gate the sheep escaped from: " + (x + 1) + " " + (y + 1));
                System.exit(0);
            }
        }

        private void sheepMove() {
            int dx = random.nextInt(3) - 1;
            int dy = random.nextInt(3) - 1;

            if (isValidCell(x + dx, y + dy) && (dx != 0 || dy != 0)) {
                if (farm[x + dx][y + dy] instanceof Empty) {
                    farm[x][y] = new Empty();
                    x = x + dx;
                    y = y + dy;
                    farm[x][y] = this;
                }
            } else if (farm[x + dx][y + dy] instanceof Gate) {
                farm[x][y] = new Empty();
                printFarm();
                System.out.println("Sheep escaped!");
                System.out.println(
                        "Coordinates of the gate the sheep escaped from: " + (x + dx + 1) + " " + (y + dy + 1));
                System.exit(0);

            }
        }

        private boolean isDogNear() {
            return (y - 1 >= 0 && farm[x][y - 1] instanceof Dog) ||
                    (y - 2 >= 0 && farm[x][y - 2] instanceof Dog) ||
                    (y - 3 >= 0 && farm[x][y - 3] instanceof Dog) ||
                    (y + 1 < farm[0].length && farm[x][y + 1] instanceof Dog) ||
                    (y + 2 < farm[0].length && farm[x][y + 2] instanceof Dog) ||
                    (y + 3 < farm[0].length && farm[x][y + 3] instanceof Dog) ||
                    (x - 1 >= 0 && farm[x - 1][y] instanceof Dog) ||
                    (x - 2 >= 0 && farm[x - 2][y] instanceof Dog) ||
                    (x - 3 >= 0 && farm[x - 3][y] instanceof Dog) ||
                    (x + 1 < farm.length && farm[x + 1][y] instanceof Dog) ||
                    (x + 2 < farm.length && farm[x + 2][y] instanceof Dog) ||
                    (x + 3 < farm.length && farm[x + 3][y] instanceof Dog);
        }

        @Override
        public String toString() {
            return "S";
        }
    }

    class Dog implements Runnable {
        private int x;
        private int y;

        Dog(int x, int y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public void run() {
            try {
                while (true) {
                    Thread.sleep(200);
                    synchronized (farm) {
                        dogMove();
                    }
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        private void dogMove() {
            int dx = random.nextInt(3) - 1;
            int dy = random.nextInt(3) - 1;

            if (isValidCell(x + dx, y + dy) && (dx != 0 || dy != 0)) {
                if (farm[x + dx][y + dy] instanceof Empty) {
                    farm[x][y] = new Empty();
                    x = x + dx;
                    y = y + dy;
                    farm[x][y] = this;
                }
            }
        }

        @Override
        public String toString() {
            return "D";
        }
    }

    class Gate {
        @Override
        public String toString() {
            return "G";
        }
    }

    class Wall {
        @Override
        public String toString() {
            return "W";
        }
    }

    class Empty {
        @Override
        public String toString() {
            return " ";
        }
    }

    public static void main(String[] args) {
        Farm farm = new Farm(14, 14);

        for (int i = 0; i < DOG_NUM; i++) {
            Thread dogThread = new Thread(farm.dogs.get(i), "Dog " + i);
            dogThread.start();
        }

        for (int i = 0; i < SHEEP_NUM; i++) {
            Thread sheepThread = new Thread(farm.sheep.get(i), " Sheep " + i);
            sheepThread.start();
        }

        while (true) {
            synchronized (farm.farm) {
                farm.printFarm();
            }
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
}
